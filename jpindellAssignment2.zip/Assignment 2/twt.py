'''
	
	prerequisites:
	
	0. create a twitter account
	
	1. obtain your access tokens: https://apps.twitter.com/
		
		1.0 create new app
	
	2. install tweepy (pip install tweepy)

	
	credit: 
	
	http://docs.tweepy.org/en/v3.4.0/streaming_how_to.html
	
	http://adilmoujahid.com/posts/2014/07/twitter-analytics/
	
	https://pythonprogramming.net/twitter-api-streaming-tweets-python-tutorial/


	
	Tweet JSON:, use http://jsonviewer.stack.hu/ to view object
	
	https://developer.twitter.com/en/docs/tweets/data-dictionary/overview/intro-to-tweet-json



	rate limiting:
	
	https://developer.twitter.com/en/docs/basics/rate-limiting

	
	streaming rate limiting:
	
	https://developer.twitter.com/en/docs/tweets/filter-realtime/guides/connecting.html

'''



#Import the necessary methods from tweepy library

from tweepy.streaming import StreamListener

from tweepy import OAuthHandler

from tweepy import Stream

import json

import time



#get keys from: https://apps.twitter.com/

#consumer key, consumer secret, access token, access secret.

ckey = 'XudMUOYzuPP8FAWtGaWOtqWXH'
csecret = 'KL3VjV0W2ovspijdciWjXCcDwVfebV1gYHEGxLilKWNAQhxEf6'

atoken = '2844124156-Rz83ugoV36xStJAGjLnwqKPPg9GLQtnJln9ws79'

asecret = 'TjfiZ3zjD0gWF9PmTMKNuKfvtaizkeINMAZdtRniINTuV'



class listener(StreamListener):

	

	def on_data(self, data):
		
		#learn about tweet json structure: https://developer.twitter.com/en/docs/tweets/data-dictionary/overview/intro-to-tweet-json
		
		tweetJson = json.loads(data)
		
		

		#tweet = tweetJson['text']
		
		username = tweetJson['user']['screen_name']
		
		links = tweetJson['entities']['urls']

	
			
		if( len(links) != 0 and tweetJson['truncated'] == False ):
			
			links = self.getLinksFromTweet(links)
	
					
			
			print( username )
			
			for l in links:
				
				print('\t', l)
			
			print ()
 
		
		time.sleep(1)	
			
		return True

	

	def getLinksFromTweet(self, linksDict):

		
		links = []
		
		for uri in linksDict:
			
			links.append( uri['expanded_url'] )


				
		return links

	
	
	def on_error(self, status):
		
		print( status )
		
		

		if status_code == 420:
			
			#returning False in on_data disconnects the stream
			
			return False
		
		return True

		


auth = OAuthHandler(ckey, csecret)

auth.set_access_token(atoken, asecret)



twitterStream = Stream(auth, listener())

twitterStream.filter(track=['baseball'])




