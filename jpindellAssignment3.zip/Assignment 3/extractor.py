#!/usr/bin/python

import requests
import justext

response = requests.get("http://usalibertypress.com/2017/09/20/the-entire-emmys-just-got-terrible-after-bashing-trump-the-entire-time/")
paragraphs = justext.justext(response.content, justext.get_stoplist("English"))
for paragraph in paragraphs:
  if not paragraph.is_boilerplate:
    print(paragraph.text)
